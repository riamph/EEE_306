clc;
clearvars;
close all;

type = 0;
[V,Del,R,H,h] = state_est(type); % Bus Voltages and angles..
X = [Del(2:end);V];
del = 180/pi*Del;
disp('-------- State Estimation --------');
disp('--------------------------');
disp('| Bus |    V   |  Angle  | ');
disp('| No  |   pu   |  Degree | ');
disp('--------------------------');
n = length(V);
for m = 1:n
    fprintf('%4g', m); fprintf('  %8.4f', V(m)); fprintf('   %8.4f', del(m)); fprintf('\n');
end
disp('---------------------------------------------');
%  Power Flow in Each Line
P_flow = P_Flow(type,V,Del);
Q_flow = Q_Flow(type,V,Del);
S = abs(P_flow-1j*Q_flow);
%% Test For Bad Data
zdata = zdatas(type);
r = zdata(: ,3) - h;
f = (r.^2)'*diag(1./R);
a = 0.001;

if f < chi2inv(1-a,length(r) -length(X))
    fprintf('No bad Measurement Found for %g significance level\n',a);
else
    fprintf('Bad Measurement Found for %g significance level\n',a);
end

disp('---------------------------------------------');
%% Sensitivity Analysis
type = 1;
[V_c,Del_c,R_c,H_c,h_c] = state_est(type); % Bus Voltages and angles..
X_c = [Del_c(2:end); V];
del_c = 180/pi*Del_c;
G = (H_c'*inv(R_c)*H_c);
F = inv(G)*H_c'*inv(R_c);
E = F*(h - h_c)+X_c -X;

Pc=inv(G);
Pa=Pc*H_c'*inv(R_c)*R*inv(R_c)*H_c*Pc;
P=inv(H'*inv(R)*H);
Cov_c = diag(Pa);
Cov = diag(P);
Cov_cng = (Cov_c - Cov)./Cov*100;
%  Power Flow in Each Line
P_flowC = P_Flow(type,V_c,Del_c);
Q_flowC = Q_Flow(type,V_c,Del_c);
P_cng = (P_flowC - P_flow)./P_flow*100;
Q_cng = (Q_flowC - Q_flow)./Q_flow*100;
S_c = abs(P_flowC-1j*Q_flowC);
S_cng = (S_c - S)./S*100;
%% Data Analysis
[Max_ang_err,bus_ang] = max(abs(E(1:n-1)));
[Max_mag_err, bus_mag] = max(abs(E(n:end)));
bus_ang = bus_ang+1;
Max_ang_err = Max_ang_err*180/pi;
[Max_Cov_ang, busI_ang] = max(abs(Cov_cng(1:n-1)));
[Max_Cov_mag, busI_mag] = max(abs(Cov_cng(n:end)));
fprintf('Maximum Average Voltage error occurs at bus %g for about %.2g pu. \n',bus_mag,Max_mag_err);
fprintf('For angle it occurs at bus %g for %.2g degree. \n', bus_ang,Max_ang_err);
disp('---------------------------------------------');
fprintf('Maximum Covariance change of Voltage occurs at bus %g (%.2g percent). \n',busI_mag,Max_Cov_mag);
fprintf('For angle, covariance change maximizes at bus %g (%.2g percent). \n',busI_ang,Max_Cov_ang);
disp('---------------------------------------------');
[MaxP, busP] = max(abs(P_cng));
[MaxP,I] = max(MaxP);
busP = [busP(I),I];
[MaxQ, busQ] = max(abs(Q_cng));
[MaxQ,I] = max(MaxQ);
busQ = [busQ(I),I];
[MaxS, busS] = max(S_cng);
[MaxS, I] = max(MaxS);
busS = [busS(I),I];
fprintf('Maximum Real power flow change occurs from bus %g to bus %g (%.2g percent)\n',busP(1),busP(2),MaxP);
fprintf('Maximum Reactive power flow change occurs from bus %g to bus %g (%.2g percent)\n',busQ(1),busQ(2),MaxQ);
fprintf('Maximum Apparent power flow change occurs from bus %g to bus %g (%.2g percent) \n',busS(1),busS(2),MaxS);
disp('---------------------------------------------');