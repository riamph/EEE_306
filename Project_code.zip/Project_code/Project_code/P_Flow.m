function P_flow = P_Flow(type,V, Del)
Del = diag(Del);
n = length(V);
I = ones(n);
Ybus = ybusppg(type);
MagYbus = abs(Ybus);
AngYbus = angle(Ybus);
phase = AngYbus+I*Del - Del*I;
P_flow = (V*V').*MagYbus.*cos(phase);
G = real(Ybus);
V = diag(V);
P_flow = -V^2*G + P_flow;
diagonal= diag(P_flow);
P_flow = P_flow - diag(diagonal);

end