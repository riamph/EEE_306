function sensitivity =sensitivity(type)
%             |Percentage|
sensitivity = [   0;    % Change in R
                  0;    % Change in X
                  0;    % Change in B/2
                  0.8;    % Change in X'mer
                  0];   % Change in variance
if type == 1 
sensitivity = diag(sensitivity(1:4))/100;
elseif type == 2
    sensitivity = 1;
elseif type == 3
    sensitivity = 1+sensitivity(5)/100;
else
    sensitivity = zeros(4);
end
end