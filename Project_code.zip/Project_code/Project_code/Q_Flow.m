function Q_flow = Q_Flow(type,V, Del)
Del = diag(Del);
n = length(V);
I = ones(n);
Ybus = ybusppg(type);
MagYbus = abs(Ybus);
AngYbus = angle(Ybus);
phase = AngYbus+I*Del - Del*I;
Q_flow = -(V*V').*MagYbus.*sin(phase);
B = imag(Ybus);
B = bbusppg(type)-B;
V = diag(V);
Q_flow = -V^2*B + Q_flow;
diagonal= diag(Q_flow);
Q_flow = Q_flow - diag(diagonal);
end